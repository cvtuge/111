#include "sr_base.hpp"
#include <time.h>
#include <math.h>

namespace webrtc {


bool BaseSuperResolution::CheckCondition(VideoFrame& input_frame){
    return false;
}

rtc::scoped_refptr<VideoFrameBuffer> BaseSuperResolution::ProcessFilter(std::unique_ptr<VideoProcessData>& process_param) {
  return nullptr;
}

}// namespace webrtc
