#ifndef MODULES_VIDEO_PROCESSING_SR_LUT_OPENGL_H_
#define MODULES_VIDEO_PROCESSING_SR_LUT_OPENGL_H_

#include "sr_base.hpp"
#include "modules/video_processing/transform/platform/android/opengl/opengl_context.hpp"
#include "modules/video_processing/transform/platform/android/opengl/opengl_texture.hpp"
#include "modules/video_processing/transform/platform/android/opengl/render/base_render.hpp"

namespace webrtc {
	using namespace std;
	class SRLutOpenGL : public BaseSuperResolution {

	public:
		SRLutOpenGL(VideoFilterType filter_type);
		~SRLutOpenGL();

		bool CheckCondition(VideoFrame& input_frame) override;

		bool isNeedChangeFilter(VideoFrame& input_frame) override;

		rtc::scoped_refptr<VideoFrameBuffer> ProcessFilter(std::unique_ptr<VideoProcessData>& process_param) override;

	private:
		rtc::scoped_refptr<VideoFrameBuffer> ProcessFilter(VideoFrame& input_frame);
	

	//
	private: 
		void InitEnv();
		void DefineShaders();
		void LoadLut();
		void UpdateTexture(int width, int height);

	private:
		OpenGLContext* mOpenGLContext = nullptr;
		std::unique_ptr<OpenGLProgram> lut_program = nullptr;
		OpenGLTexture* lut_texture_ = nullptr;
		OpenGLTexture* lut_data_texture = nullptr;

		//unsigned int lutTextureId;
		int src_width;
		int src_height;
		int dst_width;
		int dst_height;
		int tex_width;
		int tex_height;
		
		bool mInit = false;

		std::string kLutVertexShaderString;
		std::string kLutOptFragmentShaderString;
	};

}  // namespace webrtc
#endif  // MODULES_VIDEO_PROCESSING_SR_LUT_OPENGL_H_

