#include "sr_ai_opencl.h"
#include "rtc_base/logging.h"
#include "common_video/libyuv/include/webrtc_libyuv.h"
#include "third_party/libyuv/include/libyuv/planar_functions.h"
#include "api/video/video_frame_buffer.h"
#include <time.h>
#include "rtc_base/timeutils.h"
#include "super_resolution_model.h"
#include <math.h>
#include "sdk/android/src/jni/videoframe.h"
#include "sdk/android/src/jni/wrapped_native_i420_buffer.h"
#include "rtc_base/event.h"

namespace webrtc {

#define TIME_OUT 200

class OpenCLSuperResolutionAI::NewFrameTask : public rtc::QueuedTask {
 public:
  NewFrameTask(OpenCLSuperResolutionAI* mOpenCLSR, VideoFrame frame)
      : mOpenCLSR_(mOpenCLSR), frame_(std::move(frame)) {}

 private:
  bool Run() override {
    RTC_LOG(LS_INFO) << "OpenCLSuperResolutionAI::NewFrameTask : " << mOpenCLSR_;
    return true;
  }

  OpenCLSuperResolutionAI* mOpenCLSR_;
  VideoFrame frame_;
};

void OpenCLSuperResolutionAI::InitResizeModel(int newWidth, int newHeight) {
    opencl_queue_.reset(new rtc::TaskQueue("OpenCLProcess", rtc::TaskQueue::Priority::HIGH));
    if (opencl_queue_ && !opencl_queue_->IsCurrent()) {
        opencl_queue_->PostTask([this, newWidth, newHeight](){
            this->CreateAndResizeModel(newWidth, newHeight);
        });
    }
}

static bool CheckGLError(){
    for (GLint error = glGetError(); error; error = glGetError()) {
        return true;
    }
    return false;
}

OpenCLSuperResolutionAI::OpenCLSuperResolutionAI(VideoFilterType filter_type) : 
        BaseSuperResolution(filter_type){
    hardware_type_ = VideoHardwareType::kGPUType;
    RTC_LOG(LS_INFO) << "[Process] create OpenCLSuperResolutionAI";
}

OpenCLSuperResolutionAI::~OpenCLSuperResolutionAI(){
    RTC_LOG(LS_INFO) << "[Process] release OpenCLSuperResolutionAI";
    //opencl_queue_.reset();
    if (opencl_queue_) {
        // Block until all tasks have finished running.
        rtc::Event thread_sync_event;
        opencl_queue_->PostTask([&thread_sync_event] { thread_sync_event.Set(); });
        // Wait until the event has been signaled with .Set(). By then all
        // pending tasks will have finished.
        if (!thread_sync_event.Wait(5000/*, 5000ms instead of rtc::Event::kForever*/)) {
            RTC_LOG(LS_INFO) << "[Process] wait thread_sync_event time out!!!";
        }
    }
}

void OpenCLSuperResolutionAI::ExecuteModel(int inputTextureId){
    NENN::NennTensor* mInputTensor = SRNennManager->getIntputTensor(nullptr);
    NENN::NennTensor* mOutputTensor = SRNennManager->getTensor(mOutputName.c_str());
    mInputTensor->setTextureId(inputTextureId);

    //int64_t time1 = rtc::TimeMillis();
    mOutputTensor->setTextureId(mOutputTexture->GetTextureId());
    SRNennManager->runNetModel();
    SRNennManager->getOutputTensor(mOutputName.c_str());
    // //output
    //SRNennManager->getOutputTensor(mOutputName.c_str());
    //int64_t time2 = rtc::TimeMillis();
    //RTC_LOG(LS_INFO) << "cwx ExecuteModel 1 time : " << (time2 - time1);
}

int OpenCLSuperResolutionAI::CreateAndResizeModel(int newWidth, int newHeight){
    int64_t time1 = rtc::TimeMillis();
    OpenGLContext* shareContext = (OpenGLContext*)mSharedContext;

    mOpenGLContext.reset(new OpenGLContext(shareContext->Context()));
    if(mOpenGLContext->isCreateError()){
        RTC_LOG(LS_ERROR) << "[Process] Create OpenGLContext error : ";
        mInitStatus = OpenCLInitStatus::kInitFailed;
        return -1;
    }

    SRNennManager = std::unique_ptr<NENN::NennManager>(new NennManager());
    SRNennManager->createFromModelBuffer(RTSR_DIV2K4_SSIM_wd,2424);
    config.numThread = 1;
    config.inputTensorDataType = NENN_TENSOR_DATA_GPU;
    config.outputTensorDataType = NENN_TENSOR_DATA_GPU;
    //config.ioStreamType = NENN_IO_STREAM_TEXTURE;
    config.forwardType = NENN_FORWARD_OPENCL;
    config.dataType = NENN_TYPE_FP16;
    config.mContextHandle = mOpenGLContext->Context();
    NennErrCode err = SRNennManager->createContainer(config);
    if(err != NennErrCode::NENN_SUCCESS){
        RTC_LOG(LS_INFO) << "[Process] Create OpenCLSuperResolutionAI error : " << err;
        mInitStatus = OpenCLInitStatus::kInitFailed;
        return -2;
    }
    // NennSize inputSize;
    NENN::NennTensor* SRTensor = SRNennManager->getIntputTensor(nullptr);
    mNetWidth =  SRTensor->width();
    mNetHeight = SRTensor->height();
   
    SRNennManager->resizeTensor(1, 1, newHeight, newWidth, nullptr);
    mNetWidth = newWidth;
    mNetHeight = newHeight;
    int64_t time2 = rtc::TimeMillis();
    mInitStatus = OpenCLInitStatus::kInitSuccess;
    
    RTC_LOG(LS_INFO) << "[Process] OpenCLSuperResolutionAI SRNetWidth : " << mNetWidth 
                     << ", SRNetHeight : " << mNetHeight 
                     << ", handle : " << config.mContextHandle 
                     << ", time: " << (time2-time1);
    return 0;
}

bool OpenCLSuperResolutionAI::CheckCondition(VideoFrame& input_frame){
    int src_width = input_frame.width();
    int src_height = input_frame.height();
    if(mInitStatus == OpenCLInitStatus::kInitFailed || !mNoTimeOut){
        return false;
    }
    if((src_width == 640 && src_height == 360) || (src_width == 360 && src_height == 640)){ // only support 360p
        return true;
    }
    return false;
}

bool OpenCLSuperResolutionAI::isNeedChangeFilter(VideoFrame& input_frame){
    if(mInitStatus == OpenCLInitStatus::kInitFailed || !mNoTimeOut){
        return true;
    }
    return false;
}


rtc::scoped_refptr<VideoFrameBuffer> OpenCLSuperResolutionAI::ProcessFilter(VideoFrame& input_frame){
    rtc::scoped_refptr<VideoFrameBuffer> input_buffer_ = input_frame.video_frame_buffer();
    int src_width = input_frame.width();
    int src_height = input_frame.height();
    //int64_t time1 = rtc::TimeMillis();
    if (mInitStatus == OpenCLInitStatus::kInitNone) {
        mInitStatus = OpenCLInitStatus::kInitStart;
        mSharedContext = GetEGLContext();
        opencl_queue_.reset(new rtc::TaskQueue("OpenCLProcess", rtc::TaskQueue::Priority::HIGH));
        if (opencl_queue_ && !opencl_queue_->IsCurrent()) {
            opencl_queue_->PostTask([this, src_width, src_height](){
                this->CreateAndResizeModel(src_width, src_height);
            });
        }
        RTC_LOG(LS_INFO) << "[Process] OpenCLSuperResolutionAI : create model width: " << src_width << ", height: " << src_height;
    }
    if(mInitStatus != OpenCLInitStatus::kInitSuccess || CheckGLError()){
        return input_buffer_;
    }

    webrtc::VideoFrameBuffer::Type type = input_buffer_->type();
    if (type != webrtc::VideoFrameBuffer::Type::kNative){
        // RTC_LOG(LS_ERROR) << "[Process] OpenCLSuperResolutionAI : input buffer is not kNative! \n";
        return input_buffer_;
    }

    void* y_texture = input_buffer_->yTexture();
    void* u_texture = input_buffer_->uTexture();
    void* v_texture = input_buffer_->vTexture();

    int yTextureId = *static_cast<int*>(y_texture);
    int uTextureId = *static_cast<int*>(u_texture);
    int vTextureId = *static_cast<int*>(v_texture);

    if(yTextureId <= 0){
        RTC_LOG(LS_ERROR) << "[Process] OpenCLSuperResolutionAI : input texture is error! \n";
        return input_buffer_;
    }

    NENN::NennTensor* mOutputTensor = SRNennManager->getTensor(mOutputName.c_str());
    uint64_t inputTextureId = (uint64_t)yTextureId;
    if(!mOutputTexture){
        OpenGLTexture::CreateInfo mInfo;
        mInfo.mContext = mSharedContext;
        mInfo.width = mOutputTensor->width();
        mInfo.height = mOutputTensor->height();
        mInfo.type = GLTextureType::kRGBTexture;
        mInfo.dataType = GLTextureDataType::kYDataType;
        mInfo.description = "OpenCLSuperResolutionAI-RGB-Y";
        mOutputTexture = OpenGLTexture::CreateTexture(mInfo);
    }

    rtc::Event event;
    if (opencl_queue_ && !opencl_queue_->IsCurrent() && (mFirstRender == RenderStatus::kInitedRenderType || 
        mFirstRender == RenderStatus::kNoneRenderType)) {
        opencl_queue_->PostTask([this, inputTextureId, &event](){
            if(mFirstRender == RenderStatus::kNoneRenderType){
                mFirstRender = RenderStatus::kStartRenderType;
            }
            glFinish();
            this->ExecuteModel(inputTextureId);
            if(isSync && mNoTimeOut){
                event.Set();
            }
            mFirstRender = RenderStatus::kInitedRenderType;
        });
    }
    if(mFirstRender == RenderStatus::kInitedRenderType){
        isSync = true;
        mNoTimeOut = event.Wait(TIME_OUT);
        if(!CheckGLError() || mNoTimeOut){
            jni::AndroidVideoBuffer* android_buffer = static_cast<jni::AndroidVideoBuffer*>(input_buffer_.get());
            android_buffer->setTextureIds(mOutputTexture->GetTextureId(), uTextureId, vTextureId);
            android_buffer->updateSize(mOutputTensor->width(), mOutputTensor->height());
        }
    }
    
    //int64_t time2 = rtc::TimeMillis();
    if(!mNoTimeOut){
        RTC_LOG(LS_INFO) << "[Process] GPU AI SR timeout : " << mNoTimeOut;
    }
    return input_buffer_;
}

rtc::scoped_refptr<VideoFrameBuffer> OpenCLSuperResolutionAI::ProcessFilter(std::unique_ptr<VideoProcessData>& process_param) {
    if (process_param && process_param->GetPostProcessInputParam().input_frame) {
        return ProcessFilter(*(process_param->GetPostProcessInputParam().input_frame));
    }
    return nullptr;
}

}// namespace webrtc
