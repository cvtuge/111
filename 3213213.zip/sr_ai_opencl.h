#ifndef MODULES_VIDEO_PROCESSING_SR_AI_OPENCL_H_
#define MODULES_VIDEO_PROCESSING_SR_AI_OPENCL_H_

#include "sr_base.hpp"
#include "NennManager.hpp"
#include "modules/video_processing/transform/platform/android/opengl/opengl_context.hpp"
#include "modules/video_processing/transform/platform/android/opengl/opengl_texture.hpp"
#include "modules/video_processing/transform/platform/android/opengl/render/base_render.hpp"
#include "rtc_base/task_queue.h"
#include "system_wrappers/include/sleep.h"

namespace webrtc {

enum RenderStatus{ 
    kNoneRenderType = 0,
    kStartRenderType = 1,
    kInitedRenderType = 2,
 };

 enum OpenCLInitStatus{ 
    kInitNone = 0,
    kInitStart = 1,
    kInitFailed = 2,
    kInitSuccess = 3,
 };

using namespace NENN;
using namespace std;
class OpenCLSuperResolutionAI : public BaseSuperResolution {

public:
    OpenCLSuperResolutionAI(VideoFilterType filter_type);
    ~OpenCLSuperResolutionAI();
  
    bool CheckCondition(VideoFrame& input_frame) override;
    bool isNeedChangeFilter(VideoFrame& input_frame) override;

    rtc::scoped_refptr<VideoFrameBuffer> ProcessFilter(std::unique_ptr<VideoProcessData>& process_param) override;

private:
    int CreateAndResizeModel(int newWidth, int newHeight);
    rtc::scoped_refptr<VideoFrameBuffer> ProcessFilter(VideoFrame& input_frame);
    void InitResizeModel(int newWidth, int newHeight);
    void ExecuteModel(int intputTextureId);
  
private:
    class NewFrameTask;
    int mNetWidth = 0;
    int mNetHeight = 0;
    std::string mOutputName = "output";
    NennConfig config;
    std::unique_ptr<NENN::NennManager> SRNennManager;
    void* mSharedContext = nullptr;

    std::unique_ptr<OpenGLContext> mOpenGLContext = nullptr;

    // uint64_t count = 0;
    // OpenGLTexture* mInputTexture = nullptr;
    // BaseOpenGLRender* mLumToRGBRender = nullptr;
    OpenGLTexture* mOutputTexture = nullptr;
   // OpenGLTexture* mOutputTexture1 = nullptr;
   // OpenGLTexture* mOutputTexture2 = nullptr;
    RenderStatus mFirstRender = RenderStatus::kNoneRenderType;
    bool isSync = false;
    OpenCLInitStatus mInitStatus = OpenCLInitStatus::kInitNone;
    bool mNoTimeOut = true;

    //int currId = -1;
    //int outputId1 = 0;
    //int outputId2 = 0;
     //void* mEGLContext = nullptr;
    
    // NOTE (qijiyue): first to destroy, so we should put it last;
    std::unique_ptr<rtc::TaskQueue> opencl_queue_;
};

}  // namespace webrtc
#endif  // MODULES_VIDEO_PROCESSING_SR_AI_OPENCL_H_
