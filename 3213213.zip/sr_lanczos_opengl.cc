#include "sr_lanczos_opengl.h"
#include "rtc_base/logging.h"
#include "common_video/libyuv/include/webrtc_libyuv.h"
#include "third_party/libyuv/include/libyuv/planar_functions.h"
#include "api/video/video_frame_buffer.h"
#include <time.h>
#include "rtc_base/timeutils.h"
#include <math.h>
#include "sdk/android/src/jni/videoframe.h"
#include "sdk/android/src/jni/wrapped_native_i420_buffer.h"

#define STRINGIZE(x)  #x
#define SHADER_STRING(text) STRINGIZE(text)

#define MIN_SIZE 360
#define MAX_SIZE 960

#define FILTER_SIZE 8
#define PRE_FILTER_SIZE 20
#define SUF_FILTER_SIZE 20
#define MAX_DST_REPEAT_CNT 80
#define MAX_SRC_REPEAT_CNT 20
#define MIN_COMMON_DIVISOR 20

#define CHECK_GL(glFunc, flag) \
        glFunc; \
    { \
        int e = glGetError(); \
        if (e != 0) \
        { \
            RTC_LOG(LS_ERROR) << "[GLES] GL ERROR: " << e << " in " << __PRETTY_FUNCTION__ << " at line " << __LINE__;\
            flag = true;\
        } \
    }

namespace webrtc {

// Greatest common divisior
static int GCD(int a, int b) {
  int c = a % b;
  while (c != 0) {
    a = b;
    b = c;
    c = a % b;
  }
  return b;
}

static const GLfloat FullRectangleBuffer[] = {
    -1.0f, -1.0f, // Bottom left.
    1.0f, -1.0f, // Bottom right.
    -1.0f, 1.0f, // Top left.
    1.0f, 1.0f, // Top right.
};

static const GLfloat FullRectangleTextureBuffer[] = {
    0.0f, 0.0f, // Bottom left.
    1.0f, 0.0f, // Bottom right.
    0.0f, 1.0f, // Top left.
    1.0f, 1.0f, // Top right.
};

LanczosOpenGL::LanczosOpenGL(VideoFilterType filter_type) : BaseSuperResolution(filter_type){
    hardware_type_ = VideoHardwareType::kGPUType;
    gl_error_occurred_ = false;
    src_width_ = 0;
    src_height_ = 0;
    dst_width_ = 0;
    dst_height_ = 0;
    is_init_env_ = false;
    h_y_start_pos_ = NULL;
    h_y_filter_coeffs_ = NULL;
    v_y_start_pos_ = NULL;
    v_y_filter_coeffs_ = NULL;
    mOpenGLContext = NULL;
    DefineShaders();
    RTC_LOG(LS_INFO) << "[Process] create LanczosOpenGL";
}

LanczosOpenGL::~LanczosOpenGL(){
    if (h_y_start_pos_) {
      free(h_y_start_pos_);
      h_y_start_pos_ = nullptr;
    }
    if (h_y_filter_coeffs_) {
      free(h_y_filter_coeffs_);
      h_y_filter_coeffs_ = nullptr;
    }
    if (v_y_start_pos_) {
      free(v_y_start_pos_);
      v_y_start_pos_ = nullptr;
    }
    if (v_y_filter_coeffs_) {
      free(v_y_filter_coeffs_);
      v_y_filter_coeffs_ = nullptr;
    }
    h_program_pre_ = nullptr;
    v_program_pre_ = nullptr;
    h_program_no_pre_ = nullptr;
    v_program_no_pre_ = nullptr;
    RTC_LOG(LS_INFO) << "[Process] release LanczosOpenGL";
}

void LanczosOpenGL::DefineShaders() {
  kLanczosVertexShaderString = SHADER_STRING
  (
      attribute vec4 position;
      attribute vec4 texCoord;
      varying vec2 textureCoordinate;
      
      void main()
      {
          gl_Position = position;
          textureCoordinate = texCoord.xy;
      }
  );

  kDefaultLanczosFragmentShaderString = SHADER_STRING
  (
      varying highp vec2 textureCoordinate;
      uniform sampler2D inputImageTexture;
      
      void main()
      {
          gl_FragColor = texture2D(inputImageTexture, textureCoordinate);
      }
  );

  kPreCalLanczosVFragmentShaderString = SHADER_STRING
  (
      precision highp float;
      precision highp int;

      varying highp vec2 textureCoordinate;

      uniform sampler2D inputImageTexture;

      uniform float srcSize;
      uniform float dstSize;
      
      uniform float begin_filter[FILTER_SIZE * PRE_FILTER_SIZE];
      uniform float filter[FILTER_SIZE * MAX_DST_REPEAT_CNT];
      uniform float end_filter[FILTER_SIZE * SUF_FILTER_SIZE];
      uniform int repeat_filter_pos;
      uniform int end_filter_pos;
      uniform int dst_repeat_cnt;
      uniform int begin_filter_cnt;
      uniform int end_filter_cnt;
      
      uniform int  start_point_repeat_pos;
      uniform int  src_repeat_cnt;
      uniform int  start_point_repeat_num_array[MAX_SRC_REPEAT_CNT];

      void mod_from_pos(in int cur_pos, in int start_pos, in int repeat_num, out int divide_res, out int mod_res) 
      {
        int val_1 = cur_pos - start_pos;
        int val_2 = val_1 / repeat_num;
        int val_3 = val_2 * repeat_num;
        divide_res = val_2;
        mod_res = val_1 - val_3;
      }

      vec4 get_one_pixel_color(float newCoord, int filter_index, int filter_size, int is_use_begin_filter, int is_use_end_filter, int k)
      {
        vec4 color = vec4(0.0);
        vec2 new_texCoord = vec2(0.0);
        new_texCoord = vec2(textureCoordinate.x, newCoord);
        
        if (is_use_begin_filter != 0) {
          color = (texture2D(inputImageTexture, new_texCoord)) * begin_filter[filter_index * filter_size + k];
        }
        else if (is_use_end_filter != 0) {
          color = (texture2D(inputImageTexture, new_texCoord)) * end_filter[filter_index * filter_size + k];
        }
        else {
          color = (texture2D(inputImageTexture, new_texCoord)) * filter[filter_index * filter_size + k];
        }
        return color;
      }

      vec4 cal_fragment_color(float start_pos, int filter_index, int is_use_begin_filter, int is_use_end_filter)
      {
        const float EPSINON = 1e-6;
        vec4 fragmentColor = vec4(0.0);
        int filter_size = FILTER_SIZE;
        int left_shift = filter_size / 2 - 1;
        
        for (int k = 0; k < filter_size; k++) {
          if ((float(start_pos) + float(k) - float(left_shift)) >= EPSINON && (float(start_pos) + float(k) - float(left_shift)) < srcSize) {
            float newCoord = (float(start_pos) + float(k) - float(left_shift)) / srcSize;
            fragmentColor += get_one_pixel_color(newCoord, filter_index, filter_size, is_use_begin_filter, is_use_end_filter, k);
          }
        }

        if ((fragmentColor.r > 1.0) || (fragmentColor.r < EPSINON)) {
          float newCoord = float(start_pos) / srcSize;
          vec2 newTexCoord = vec2(0.0);
          newTexCoord = vec2(textureCoordinate.x, newCoord);
          fragmentColor = texture2D(inputImageTexture, newTexCoord);
        }

        return fragmentColor;
      }

      void main()
      {
        float curPos = dstSize;
        curPos = textureCoordinate.y * dstSize;
        
        int intCurPos = int(floor(curPos));
        int filter_index = 0;
        float start_pos = 0.0;
        int is_use_begin_filter = 0;
        int is_use_end_filter = 0;
        
        if (intCurPos < repeat_filter_pos) {
          filter_index = intCurPos;
          is_use_begin_filter = 1;
        }
        else if (intCurPos >= end_filter_pos) {
          filter_index = intCurPos - end_filter_pos;
          is_use_end_filter = 1;
        }
        else {
          int divide_res = 0;
          mod_from_pos(intCurPos, repeat_filter_pos, dst_repeat_cnt, divide_res, filter_index);
        }
        
        if (intCurPos < start_point_repeat_pos) {
          start_pos = 0.0;
        }
        else {
          int idx = 0;
          int divide_res = 0;
          mod_from_pos(intCurPos, start_point_repeat_pos, dst_repeat_cnt, divide_res, idx);
          int total_num = 0;
          for (int i = 0; i < src_repeat_cnt; i++) {
            total_num += start_point_repeat_num_array[i];
            if (idx < total_num) {
              start_pos = float(i + 1 + divide_res * src_repeat_cnt);
              break;
            }
          }
        }
        start_pos += 0.5;
        
        gl_FragColor = cal_fragment_color(start_pos, filter_index, is_use_begin_filter, is_use_end_filter);
      }
  );

  kPreCalLanczosHFragmentShaderString = SHADER_STRING
  (
      precision highp float;
      precision highp int;

      varying highp vec2 textureCoordinate;

      uniform sampler2D inputImageTexture;

      uniform float srcSize;
      uniform float dstSize;
      
      uniform float begin_filter[FILTER_SIZE * PRE_FILTER_SIZE];
      uniform float filter[FILTER_SIZE * MAX_DST_REPEAT_CNT];
      uniform float end_filter[FILTER_SIZE * SUF_FILTER_SIZE];
      uniform int repeat_filter_pos;
      uniform int end_filter_pos;
      uniform int dst_repeat_cnt;
      uniform int begin_filter_cnt;
      uniform int end_filter_cnt;
      
      uniform int  start_point_repeat_pos;
      uniform int  src_repeat_cnt;
      uniform int  start_point_repeat_num_array[MAX_SRC_REPEAT_CNT];

      void mod_from_pos(in int cur_pos, in int start_pos, in int repeat_num, out int divide_res, out int mod_res) 
      {
        int val_1 = cur_pos - start_pos;
        int val_2 = val_1 / repeat_num;
        int val_3 = val_2 * repeat_num;
        divide_res = val_2;
        mod_res = val_1 - val_3;
      }

      vec4 get_one_pixel_color(float newCoord, int filter_index, int filter_size, int is_use_begin_filter, int is_use_end_filter, int k)
      {
        vec4 color = vec4(0.0);
        vec2 new_texCoord = vec2(0.0);
        new_texCoord = vec2(newCoord, textureCoordinate.y);
        
        if (is_use_begin_filter != 0) {
          color = (texture2D(inputImageTexture, new_texCoord)) * begin_filter[filter_index * filter_size + k];
        }
        else if (is_use_end_filter != 0) {
          color = (texture2D(inputImageTexture, new_texCoord)) * end_filter[filter_index * filter_size + k];
        }
        else {
          color = (texture2D(inputImageTexture, new_texCoord)) * filter[filter_index * filter_size + k];
        }
        return color;
      }

      vec4 cal_fragment_color(float start_pos, int filter_index, int is_use_begin_filter, int is_use_end_filter)
      {
        const float EPSINON = 1e-6;
        vec4 fragmentColor = vec4(0.0);
        int filter_size = FILTER_SIZE;
        int left_shift = filter_size / 2 - 1;

        for (int k = 0; k < filter_size; k++) {
          if ((float(start_pos) + float(k) - float(left_shift)) >= EPSINON && (float(start_pos) + float(k) - float(left_shift)) < srcSize) {
            float newCoord = (float(start_pos) + float(k) - float(left_shift)) / srcSize;
            fragmentColor += get_one_pixel_color(newCoord, filter_index, filter_size, is_use_begin_filter, is_use_end_filter, k);
          }
        }

        if ((fragmentColor.r > 1.0) || (fragmentColor.r < EPSINON)) {
          float newCoord = float(start_pos) / srcSize;
          vec2 newTexCoord = vec2(0.0);
          newTexCoord = vec2(newCoord, textureCoordinate.y);
          fragmentColor = texture2D(inputImageTexture, newTexCoord);
        }

        return fragmentColor;
      }

      void main()
      {
        float curPos = dstSize;
        curPos = textureCoordinate.x * dstSize;
        
        int intCurPos = int(floor(curPos));
        int filter_index = 0;
        float start_pos = 0.0;
        int is_use_begin_filter = 0;
        int is_use_end_filter = 0;
        
        if (intCurPos < repeat_filter_pos) {
          filter_index = intCurPos;
          is_use_begin_filter = 1;
        }
        else if (intCurPos >= end_filter_pos) {
          filter_index = intCurPos - end_filter_pos;
          is_use_end_filter = 1;
        }
        else {
          int divide_res = 0;
          mod_from_pos(intCurPos, repeat_filter_pos, dst_repeat_cnt, divide_res, filter_index);
        }
        
        if (intCurPos < start_point_repeat_pos) {
          start_pos = 0.0;
        }
        else {
          int idx = 0;
          int divide_res = 0;
          mod_from_pos(intCurPos, start_point_repeat_pos, dst_repeat_cnt, divide_res, idx);
          int total_num = 0;
          for (int i = 0; i < src_repeat_cnt; i++) {
            total_num += start_point_repeat_num_array[i];
            if (idx < total_num) {
              start_pos = float(i + 1 + divide_res * src_repeat_cnt);
              break;
            }
          }
        }
        start_pos += 0.5;
        
        gl_FragColor = cal_fragment_color(start_pos, filter_index, is_use_begin_filter, is_use_end_filter);
      }
  );

  kLanczosFragmentShaderString = SHADER_STRING
  (
    precision highp float;
    precision highp int;

    varying highp vec2 textureCoordinate;

    uniform sampler2D inputImageTexture;
    uniform int flag;
    uniform float srcSize;
    uniform float dstSize;

    vec4 cal_fragment_color(float start_pos, float coeffs[FILTER_SIZE])
    {
      const float EPSINON = 1e-6;
      vec4 fragmentColor = vec4(0.0);
      vec2 newTexCoord = vec2(0.0);
      int filter_size = FILTER_SIZE;
      int left_shift = filter_size / 2 - 1;
      // int right_shift = filter_size / 2;

      for (int k = 0; k < filter_size; k++) {
        if ((start_pos + float(k) - float(left_shift)) >= EPSINON && (start_pos + float(k) - float(left_shift)) < srcSize) {
          float newCoord = (start_pos + float(k) - float(left_shift)) / srcSize;
          if (flag == 1) {
            newTexCoord = vec2(textureCoordinate.x, newCoord);
          }
          else {
            newTexCoord = vec2(newCoord, textureCoordinate.y);
          }
          fragmentColor += (texture2D(inputImageTexture, newTexCoord)) * coeffs[k];
        }
      }

      if ((fragmentColor.r > 1.0) || (fragmentColor.r < EPSINON)) {
        float newCoord = start_pos / srcSize;
        if (flag == 1) {
          newTexCoord = vec2(textureCoordinate.x, newCoord);
        }
        else {
          newTexCoord = vec2(newCoord, textureCoordinate.y);
        }
        fragmentColor = texture2D(inputImageTexture, newTexCoord);
      }

      return fragmentColor;
    }
    
    void main()
    {
      const float EPSINON = 1e-6;
      const float PI = 3.1415926;
      int filter_size = FILTER_SIZE;
      int mid_filter_pos = filter_size / 2 - 1;
      float start_pos = 0.0;
      float scale = srcSize / dstSize;
      float curPos = dstSize;
      if (flag == 1) {
        curPos = textureCoordinate.y * dstSize;
      }
      else {
        curPos = textureCoordinate.x * dstSize;
      }
      float fy = (curPos + 0.5) * scale - 0.5;
      float sy = floor(fy);
      fy -= sy;
      if (sy < EPSINON) {
        sy = 0.0;
      }
      if (sy > (dstSize - 1.0)) {
        sy = dstSize - 1.0;
      }
      
      start_pos = sy + 0.5;

      float coeffs[FILTER_SIZE];
      int weights[FILTER_SIZE];
      if (fy < EPSINON) {
        for (int t = 0; t < filter_size; t++) {
          coeffs[t] = 0.0;
        }
        coeffs[mid_filter_pos] = 1.0;
      }
      else {
        float sum = 0.0;
        for (int t = 0; t < filter_size; ++t)
        {
          float dy = abs(fy + float(mid_filter_pos) - float(t)) * PI;
          if ((sy - float(mid_filter_pos) + float(t)) < EPSINON || (sy - float(mid_filter_pos) + float(t)) >= (srcSize)) {
            coeffs[t] = 0.0;
          }
          else if (abs(fy + float(mid_filter_pos - t)) > float(filter_size / 2)) {
            coeffs[t] = 0.0;
          }
          else {
            coeffs[t] = ((sin(dy)*sin(dy / float(filter_size / 2))) / (dy * dy / float(filter_size / 2)));
          }
          sum += coeffs[t];
        }

        for (int t = 0; t < filter_size; ++t) {
          coeffs[t] /= sum;
        }
      }
      
      gl_FragColor = cal_fragment_color(start_pos, coeffs);
      
    }
  );
}

bool LanczosOpenGL::CheckCondition(VideoFrame& input_frame){
    int src_width = input_frame.width();
    int src_height = input_frame.height();
    if((src_width < MIN_SIZE || src_width > MAX_SIZE) || (src_height < MIN_SIZE || src_height > MAX_SIZE)){
        return false;
    }
    return NeedPreCalCoeffs(src_width, src_height);
}

bool LanczosOpenGL::isNeedChangeFilter(VideoFrame& input_frame) {
    int src_width = input_frame.width();
    int src_height = input_frame.height();
    if((src_width < MIN_SIZE || src_width > MAX_SIZE) || (src_height < MIN_SIZE || src_height > MAX_SIZE)){
        return false;
    }
    if (!NeedPreCalCoeffs(src_width, src_height)){
        return true;
    }
    return false;
}


void LanczosOpenGL::InitEnv() {
    if(!mOpenGLContext){
        mOpenGLContext = (OpenGLContext*)GetEGLContext();
    }
    mOpenGLContext->MakeCurrent();

    use_pre_cal_program_ = NeedPreCalCoeffs(src_width_, src_height_);

    if (use_pre_cal_program_) {
      InitLanczosFilter(src_width_, dst_width_, &h_y_start_pos_, &h_y_filter_coeffs_);
      InitLanczosFilter(src_height_, dst_height_, &v_y_start_pos_, &v_y_filter_coeffs_);
    }

    //init program
    if (use_pre_cal_program_) {
      if (h_program_pre_ == nullptr) {
        h_program_pre_.reset(new OpenGLProgram(kLanczosVertexShaderString.c_str(), kPreCalLanczosHFragmentShaderString.c_str()));
      }
      if (v_program_pre_ == nullptr) {
        v_program_pre_.reset(new OpenGLProgram(kLanczosVertexShaderString.c_str(), kPreCalLanczosVFragmentShaderString.c_str()));
      }
    }
    else {
      if (h_program_no_pre_ == nullptr) {
        h_program_no_pre_.reset(new OpenGLProgram(kLanczosVertexShaderString.c_str(), kLanczosFragmentShaderString.c_str()));
      }
      if (v_program_no_pre_ == nullptr) {
        v_program_no_pre_.reset(new OpenGLProgram(kLanczosVertexShaderString.c_str(), kLanczosFragmentShaderString.c_str()));
      }
    }
    
    //init framebuffer
    if (h_y_texture_) {
      OpenGLTexture::ReleaseTexture(h_y_texture_, mOpenGLContext);
      h_y_texture_ = nullptr;
    }
    OpenGLTexture::CreateInfo h_y_texture_info;
    h_y_texture_info.mContext = mOpenGLContext;
    h_y_texture_info.textureId = 0;
    h_y_texture_info.width = dst_width_;
    h_y_texture_info.height = src_height_;
    h_y_texture_info.bindFrameBuffer = true;
    h_y_texture_info.type = GLTextureType::kRGBTexture;
    h_y_texture_info.dataType = GLTextureDataType::kYDataType;
    h_y_texture_info.description = "LanczosOpenGL-RGB-hY";
    h_y_texture_ = OpenGLTexture::CreateTexture(h_y_texture_info);

    if (v_y_texture_) {
      OpenGLTexture::ReleaseTexture(v_y_texture_, mOpenGLContext);
      v_y_texture_ = nullptr;
    }
    OpenGLTexture::CreateInfo v_y_texture_info;
    v_y_texture_info.mContext = mOpenGLContext;
    v_y_texture_info.textureId = 0;
    v_y_texture_info.width = dst_width_;
    v_y_texture_info.height = dst_height_;
    v_y_texture_info.bindFrameBuffer = true;
    v_y_texture_info.type = GLTextureType::kRGBTexture;
    v_y_texture_info.dataType = GLTextureDataType::kYDataType;
    v_y_texture_info.description = "LanczosOpenGL-RGB-vY";
    v_y_texture_ = OpenGLTexture::CreateTexture(v_y_texture_info);

    is_init_env_ = true;
}

bool LanczosOpenGL::NeedPreCalCoeffs(int src_width, int src_height) {
    bool ret = true;
    if(src_width >= src_height){
        dst_width_ = 1280;
        dst_height_ = 1280 * src_height / src_width;
        if(dst_height_ % 2 != 0){
            dst_height_ = dst_height_ + 1;
        }
    }
    if(src_width < src_height){
        dst_height_ = 1280;
        dst_width_ = 1280 * src_width / src_height;
        if(dst_width_ % 2 != 0) {
            dst_width_ = dst_width_ + 1;
        }
    }

    int max_common_divisor = 1;
    max_common_divisor = GCD(dst_width_, src_width);
    int src_repeat_cnt = src_width / max_common_divisor;
    int dst_repeat_cnt = dst_width_ / max_common_divisor;
    if (max_common_divisor <= MIN_COMMON_DIVISOR || src_repeat_cnt > MAX_SRC_REPEAT_CNT || dst_repeat_cnt > MAX_DST_REPEAT_CNT) {
      ret = false;
    }
    // RTC_LOG(LS_INFO) << "[Process] LanczosOpenGL :  width max_common_divisor: " << max_common_divisor << " src_repeat_cnt: " << src_repeat_cnt << " dst_repeat_cnt: " << dst_repeat_cnt;

    max_common_divisor = GCD(dst_height_, src_height);
    src_repeat_cnt = src_height / max_common_divisor;
    dst_repeat_cnt = dst_height_ / max_common_divisor;
    if (max_common_divisor <= MIN_COMMON_DIVISOR || src_repeat_cnt > MAX_SRC_REPEAT_CNT || dst_repeat_cnt > MAX_DST_REPEAT_CNT) {
      ret = false;
    }
    // RTC_LOG(LS_INFO) << "[Process] LanczosOpenGL :  height max_common_divisor: " << max_common_divisor << " src_repeat_cnt: " << src_repeat_cnt << " dst_repeat_cnt: " << dst_repeat_cnt;
    return ret;
}

void LanczosOpenGL::DoLanczos(int texture_id, 
                              int src_size, 
                              int dst_size, 
                              int view_width,
                              int view_height,
                              int* start_pos,
                              float* filter_coeffs,
                              OpenGLTexture* dst_texture,
                              std::shared_ptr<OpenGLProgram> program,
                              int flag) {

  int src_repeat_cnt = 0;
  int dst_repeat_cnt = 0;
  int start_pos_num_array[MAX_SRC_REPEAT_CNT];  
  int start_pos_repeat_pos = -1;

  if (use_pre_cal_program_) {
    int max_common_divisor = 0;
    for (int i = src_size; i > 0; i--) {
      if ((src_size % i == 0) && (dst_size % i == 0)) {
        max_common_divisor = i;
        break;
      }
    }
    src_repeat_cnt = src_size / max_common_divisor;
    dst_repeat_cnt = dst_size / max_common_divisor;

    start_pos_repeat_pos = -1;
    int start_pos_num_array_idx = 0;
    int start_pos_repeat_num = 0;
    int i = 0;
    for (i = 0; i < dst_size; i++) {
      if (start_pos[i] > 0) {
        start_pos_repeat_pos = i;
        break;
      }
    }
    if (i == dst_size) {
      start_pos_repeat_pos = dst_size - 1;
    }
    if (start_pos_repeat_pos >= 0) {
      int val = start_pos[start_pos_repeat_pos];
      for (int i = start_pos_repeat_pos + 1; i <= start_pos_repeat_pos + dst_repeat_cnt; i++) {
        start_pos_repeat_num++;
        if (val != start_pos[i]) {
          start_pos_num_array[start_pos_num_array_idx] = start_pos_repeat_num;
          val = start_pos[i];
          start_pos_num_array_idx++;
          start_pos_repeat_num = 0;
        }
      }
    }
  }

  if(!mOpenGLContext){
      mOpenGLContext = (OpenGLContext*)GetEGLContext();
  }
  mOpenGLContext->MakeCurrent();

  // if (use_pre_cal_program_) {
  //   RTC_LOG(LS_INFO) << "[WILL][GLES] uniforms- srcSize: " << (float)src_size << " dstSize: " << (float)dst_size
  //                   << " flag: " << flag << " repeat_filter_pos: " << PRE_FILTER_SIZE << " end_filter_pos: " << dst_size - SUF_FILTER_SIZE
  //                   << " dst_repeat_cnt: " << dst_repeat_cnt << " begin_filter_cnt: " << PRE_FILTER_SIZE 
  //                   << " end_filter_cnt: " << SUF_FILTER_SIZE << " begin_filter: " << filter_coeffs[0]
  //                   << " filter: " << *(filter_coeffs + (FILTER_SIZE) * (PRE_FILTER_SIZE)) 
  //                   << " end_filter: " << *(filter_coeffs + (FILTER_SIZE) * (dst_size - SUF_FILTER_SIZE))
  //                   << " start_point_repeat_pos: " << start_pos_repeat_pos
  //                   << " src_repeat_cnt: " << src_repeat_cnt
  //                   << " start_point_repeat_num_array: " << start_pos_num_array[0];
  // }

  CHECK_GL(glBindFramebuffer(GL_FRAMEBUFFER, dst_texture->GetFrameBufferId()), gl_error_occurred_);
  CHECK_GL(glViewport(0, 0, view_width, view_height), gl_error_occurred_);
  CHECK_GL(glClearColor(0, 0, 0, 1), gl_error_occurred_);
  CHECK_GL(glClear(GL_COLOR_BUFFER_BIT), gl_error_occurred_);
  CHECK_GL(program->UseProgram(), gl_error_occurred_);
  int inPosLocation = program->GetAttribLocation("position");
  int inTcLocation = program->GetAttribLocation("texCoord");
  CHECK_GL(glEnableVertexAttribArray(inPosLocation), gl_error_occurred_);
  CHECK_GL(glVertexAttribPointer(inPosLocation, 2, GL_FLOAT, false, 0, FullRectangleBuffer), gl_error_occurred_);
  CHECK_GL(glEnableVertexAttribArray(inTcLocation), gl_error_occurred_);
  CHECK_GL(glVertexAttribPointer(inTcLocation, 2, GL_FLOAT, false, 0, FullRectangleTextureBuffer), gl_error_occurred_);
  CHECK_GL(glActiveTexture(GL_TEXTURE2), gl_error_occurred_);
  CHECK_GL(glBindTexture(GL_TEXTURE_2D, texture_id), gl_error_occurred_);
  CHECK_GL(glUniform1i(program->GetUniformLocation("inputImageTexture"), 2), gl_error_occurred_);
  CHECK_GL(glUniform1f(program->GetUniformLocation("srcSize"), (float)src_size), gl_error_occurred_);
  CHECK_GL(glUniform1f(program->GetUniformLocation("dstSize"), (float)dst_size), gl_error_occurred_);
  // CHECK_GL(glUniform1i(program.GetUniformLocation("flag"), flag), gl_error_occurred_);
  if (use_pre_cal_program_) {
    CHECK_GL(glUniform1i(program->GetUniformLocation("repeat_filter_pos"), PRE_FILTER_SIZE), gl_error_occurred_);
    CHECK_GL(glUniform1i(program->GetUniformLocation("end_filter_pos"), dst_size - SUF_FILTER_SIZE), gl_error_occurred_);
    CHECK_GL(glUniform1i(program->GetUniformLocation("dst_repeat_cnt"), dst_repeat_cnt), gl_error_occurred_);
    CHECK_GL(glUniform1i(program->GetUniformLocation("begin_filter_cnt"), PRE_FILTER_SIZE), gl_error_occurred_);
    CHECK_GL(glUniform1i(program->GetUniformLocation("end_filter_cnt"), SUF_FILTER_SIZE), gl_error_occurred_);
    CHECK_GL(glUniform1fv(program->GetUniformLocation("begin_filter"), (FILTER_SIZE) * (PRE_FILTER_SIZE), filter_coeffs), gl_error_occurred_);
    CHECK_GL(glUniform1fv(program->GetUniformLocation("filter"), (FILTER_SIZE) * dst_repeat_cnt, filter_coeffs + (FILTER_SIZE) * (PRE_FILTER_SIZE)), gl_error_occurred_);
    CHECK_GL(glUniform1fv(program->GetUniformLocation("end_filter"), (FILTER_SIZE) * (SUF_FILTER_SIZE), filter_coeffs + (FILTER_SIZE) * (dst_size - SUF_FILTER_SIZE)), gl_error_occurred_);
    CHECK_GL(glUniform1i(program->GetUniformLocation("start_point_repeat_pos"), start_pos_repeat_pos), gl_error_occurred_);
    CHECK_GL(glUniform1i(program->GetUniformLocation("src_repeat_cnt"), src_repeat_cnt), gl_error_occurred_);
    CHECK_GL(glUniform1iv(program->GetUniformLocation("start_point_repeat_num_array"), src_repeat_cnt, start_pos_num_array), gl_error_occurred_);
  }
  CHECK_GL(glDrawArrays(GL_TRIANGLE_STRIP, 0, 4), gl_error_occurred_);
  CHECK_GL(glBindFramebuffer(GL_FRAMEBUFFER, 0), gl_error_occurred_);
  CHECK_GL(glDisableVertexAttribArray(inPosLocation), gl_error_occurred_);
  CHECK_GL(glDisableVertexAttribArray(inTcLocation), gl_error_occurred_);
  CHECK_GL(glBindTexture(GL_TEXTURE_2D, 0), gl_error_occurred_);
}

rtc::scoped_refptr<VideoFrameBuffer> LanczosOpenGL::ProcessFilter(VideoFrame& input_frame){
    rtc::scoped_refptr<VideoFrameBuffer> input_buffer_ = input_frame.video_frame_buffer();

    if (gl_error_occurred_) {
      return input_buffer_;
    }

    int src_width = input_frame.width();
    int src_height = input_frame.height();

    if(!mOpenGLContext){
        mOpenGLContext = (OpenGLContext*)GetEGLContext();
    }
    mOpenGLContext->MakeCurrent();

    if (!is_init_env_ || 
      src_width != src_width_ ||
      src_height != src_height_) {
      src_width_ = src_width;
      src_height_ = src_height;
      InitEnv();
    }

    webrtc::VideoFrameBuffer::Type type = input_buffer_->type();
    if (type != webrtc::VideoFrameBuffer::Type::kNative){
        // RTC_LOG(LS_ERROR) << "[Process] LanczosOpenGL : input buffer is not kNative! \n";
        return input_buffer_;
    }

    void* y_texture = input_buffer_->yTexture();
    void* u_texture = input_buffer_->uTexture();
    void* v_texture = input_buffer_->vTexture();

    int yTextureId = *static_cast<int*>(y_texture);
    int uTextureId = *static_cast<int*>(u_texture);
    int vTextureId = *static_cast<int*>(v_texture);

    // RTC_LOG(LS_INFO) << "[Process] LanczosOpenGL :" << yTextureId << ", " << uTextureId << ", " << vTextureId;

    if(yTextureId <= 0){
        RTC_LOG(LS_ERROR) << "[Process] LanczosOpenGL : input texture is error! \n";
        return input_buffer_;
    }

    jni::AndroidVideoBuffer* android_buffer = static_cast<jni::AndroidVideoBuffer*>(input_buffer_.get());

    std::shared_ptr<OpenGLProgram> h_program = nullptr;
    std::shared_ptr<OpenGLProgram> v_program = nullptr;
    if (use_pre_cal_program_) {
      h_program = h_program_pre_;
      v_program = v_program_pre_;
    }
    else {
      h_program = h_program_no_pre_;
      v_program = v_program_no_pre_;
    }
    //y
    //h
    DoLanczos(yTextureId, 
              src_width_,
              dst_width_, 
              dst_width_, 
              src_height_, 
              h_y_start_pos_, 
              h_y_filter_coeffs_, 
              h_y_texture_, 
              h_program,
              0);
    //v
    DoLanczos(h_y_texture_->GetTextureId(), 
              src_height_, 
              dst_height_, 
              dst_width_, 
              dst_height_, 
              v_y_start_pos_, 
              v_y_filter_coeffs_, 
              v_y_texture_, 
              v_program,
              1);
    //
    CHECK_GL(glFlush(), gl_error_occurred_);

    android_buffer->setTextureIds(v_y_texture_->GetTextureId(), uTextureId, vTextureId);
    android_buffer->updateSize(dst_width_, dst_height_);

    return input_buffer_;
}


void LanczosOpenGL::InitLanczosFilter(int src_size, int dst_size, int **pos, float **kweights) {
  float scale = (float)(1.0 * src_size / dst_size);
  int filter_size = FILTER_SIZE;
  int filter_mid_pos = filter_size / 2 - 1;
  if (*pos) {
      free(*pos);
      *pos = NULL;
  }
  if (*kweights) {
      free(*kweights);
      *kweights = NULL;
  }
  *pos = (int*)malloc(dst_size * sizeof(**pos));
  *kweights=(float*)malloc(dst_size * filter_size * sizeof(*kweights));
  for (int j = 0; j < dst_size; ++j) {
    float fy = (float)((j + 0.5) * scale - 0.5);
    int sy = floor(fy);
    fy -= sy;    
    sy = sy > 0 ? sy : 0;
    sy = sy < dst_size - 1 ? sy : dst_size - 1;
    (*pos)[j] = sy;
    float *coeffs=(float*)malloc(filter_size * sizeof(float));
    if (fy < 0.0000001) {
      float sum = 0.0;
      for (int t = 0; t < filter_size; t++) {
        coeffs[t] = 0;
      }
      coeffs[filter_mid_pos] = 1;
      for (int t = 0; t < filter_size; ++t) {
        sum += coeffs[t];
      }
      sum = 1.f / sum;
      for (int t = 0; t < filter_size; ++t) {
        coeffs[t] *= sum;
        (*kweights)[j * filter_size + t] = coeffs[t];
      }
    }
    else {
      float sum = 0.0;
      for (int t = 0; t < filter_size; ++t)
      {
        double dy = fabs(fy + (float)(filter_mid_pos - t)) * 3.1415926535897932384626433832795;
        if ((sy - filter_mid_pos + t) < 0 || (sy - filter_mid_pos + t) >= src_size)
          coeffs[t] = 0;
        else if (fabs(fy + (float)(filter_mid_pos - t)) > 4.0)
          coeffs[t] = 0;
        else
          coeffs[t] = (float)((sin(dy)*sin(dy / float(filter_size / 2))) / (dy * dy / float(filter_size / 2)));
        sum += coeffs[t];
        //std::cout << coeffs[t] << std::endl;
      }

      sum = 1.f / sum;
      for (int t = 0; t < filter_size; ++t) {
        coeffs[t] *= sum;
        (*kweights)[j * filter_size + t] = coeffs[t];
//        std::cout<< (*kweights)[j * 8 + t] <<std::endl;
      }
    }
    free(coeffs);
  }
}

rtc::scoped_refptr<VideoFrameBuffer> LanczosOpenGL::ProcessFilter(std::unique_ptr<VideoProcessData>& process_param) {
  if (process_param &&
      process_param->GetPostProcessInputParam().input_frame) {
    return ProcessFilter(*(process_param->GetPostProcessInputParam().input_frame));
  }
  return nullptr;
}

}// namespace webrtc
