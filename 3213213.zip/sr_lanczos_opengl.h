#ifndef MODULES_VIDEO_PROCESSING_SR_LANCZOS_OPENCL_H_
#define MODULES_VIDEO_PROCESSING_SR_LANCZOS_OPENCL_H_

#include "sr_base.hpp"
#include "modules/video_processing/transform/platform/android/opengl/opengl_context.hpp"
#include "modules/video_processing/transform/platform/android/opengl/opengl_texture.hpp"
#include "modules/video_processing/transform/platform/android/opengl/render/base_render.hpp"

namespace webrtc {
using namespace std;
class LanczosOpenGL : public BaseSuperResolution {

public:
    LanczosOpenGL(VideoFilterType filter_type);
    ~LanczosOpenGL();
  
    bool CheckCondition(VideoFrame& input_frame) override;
    bool isNeedChangeFilter(VideoFrame& input_frame) override;

    rtc::scoped_refptr<VideoFrameBuffer> ProcessFilter(std::unique_ptr<VideoProcessData>& process_param) override;

private:
    rtc::scoped_refptr<VideoFrameBuffer> ProcessFilter(VideoFrame& input_frame);

private:
    void InitLanczosFilter(int src_size, int dst_size, int **pos, float **kweights);
    void InitEnv();
    bool NeedPreCalCoeffs(int src_width, int src_height);
    void DoLanczos(int texture_id, 
                    int src_size, 
                    int dst_size, 
                    int view_width,
                    int view_height,
                    int* start_pos,
                    float* filter_coeffs,
                    OpenGLTexture* dst_texture,
                    std::shared_ptr<OpenGLProgram> program,
                    int flag);
    void DefineShaders();
  
private:
    OpenGLContext* mOpenGLContext = nullptr;
    std::shared_ptr<OpenGLProgram> h_program_pre_ = nullptr;
    std::shared_ptr<OpenGLProgram> v_program_pre_ = nullptr;
    std::shared_ptr<OpenGLProgram> h_program_no_pre_ = nullptr;
    std::shared_ptr<OpenGLProgram> v_program_no_pre_ = nullptr;
    OpenGLTexture* h_y_texture_ = nullptr;
    OpenGLTexture* v_y_texture_ = nullptr;
    bool is_init_env_;
    int src_width_;
    int src_height_;
    int dst_width_;
    int dst_height_;
    int* h_y_start_pos_;
    float* h_y_filter_coeffs_;
    int* v_y_start_pos_;
    float* v_y_filter_coeffs_;
    bool use_pre_cal_program_;
    std::string kLanczosVertexShaderString;
    std::string kDefaultLanczosFragmentShaderString;
    std::string kPreCalLanczosHFragmentShaderString;
    std::string kPreCalLanczosVFragmentShaderString;
    std::string kLanczosFragmentShaderString;
    bool gl_error_occurred_;
};

}  // namespace webrtc
#endif  // MODULES_VIDEO_PROCESSING_SR_LANCZOS_OPENCL_H_
