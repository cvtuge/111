#ifndef MODULES_VIDEO_PROCESSING_FILTER_BASE_SUPER_RESOLUTION_H_
#define MODULES_VIDEO_PROCESSING_FILTER_BASE_SUPER_RESOLUTION_H_
#include <memory>
#include "modules/video_processing/filter/video_process_filter.h"
#include "third_party/libyuv/include/libyuv.h"

namespace webrtc {

using namespace std;

class BaseSuperResolution : public VideoProcessFilter {

public:
    BaseSuperResolution(VideoFilterType filter_type){
        filter_type_ = filter_type;
    }

    virtual ~BaseSuperResolution() = default;
  
    virtual bool CheckCondition(VideoFrame& input_frame) override;
    virtual rtc::scoped_refptr<VideoFrameBuffer> ProcessFilter(std::unique_ptr<VideoProcessData>& process_param) override;

};

}  // namespace webrtc
#endif  // MODULES_VIDEO_PROCESSING_FILTER_BASE_SUPER_RESOLUTION_H_
