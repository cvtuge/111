#ifndef MODULES_VIDEO_PROCESSING_FILTER_SUPER_RESOLUTION_LUT_H_
#define MODULES_VIDEO_PROCESSING_FILTER_SUPER_RESOLUTION_LUT_H_
#include "sr_base.hpp" 
#if defined(_MSC_VER)
#include <immintrin.h>
#else
#include <x86intrin.h>
#endif
namespace webrtc {
	using namespace std;

	class SRLutCPU : public BaseSuperResolution {
         public:
          SRLutCPU(VideoFilterType filter_type);
          ~SRLutCPU();

		  bool CheckCondition(VideoFrame& input_frame) override;
          //VideoProcessResult ProcessFilter(unique_ptr<VideoProcessData>& process_param) override;
          rtc::scoped_refptr<VideoFrameBuffer> ProcessFilter(std::unique_ptr<VideoProcessData>& process_param) override;

		 private:
          void initParams();
          rtc::scoped_refptr<VideoFrameBuffer> ProcessFilter(VideoFrame& input_frame, I420BufferPool& buffer_pool);
          __m256i* SetLut();
          void initOutBuffer();
          //void Timer_recorder(float dur);

		 private:
          __m256i* LUT_;
          bool mIsInit = false;
          bool mOutBufferIsNewed = false;
          int inlinesize;
          int outlinesize;
		  uint8_t* inBuffer;
		  uint8_t* inbuf[2];
		  uint8_t* outbuf[3];
          int8_t* outBuffer;
          int16_t* outBuffer_16bit; 
	};


}

#endif  // MODULES_VIDEO_PROCESSING_FILTER_SUPER_RESOLUTION_LUT_H_
