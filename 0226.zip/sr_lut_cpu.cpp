#include <math.h>
#include <time.h>
#include "api/video/video_frame_buffer.h"
#include "common_video/libyuv/include/webrtc_libyuv.h"
#include "rtc_base/logging.h"
#include "sr_lut_cpu.h"
#include "third_party/libyuv/include/libyuv/planar_functions.h"
#include "lut_model_enhanced.h"

namespace webrtc {


SRLutCPU::SRLutCPU(VideoFilterType filter_type): BaseSuperResolution(filter_type) {
	mIsInit = false;
	hardware_type_ = VideoHardwareType::kCPUType;
	RTC_LOG(LS_INFO) << "[Process] create SR-LUT\n";
}

SRLutCPU::~SRLutCPU() {
  if (mOutBufferIsNewed){
    delete[] outBuffer;
    outBuffer = NULL;
    delete[] outBuffer_16bit;
    outBuffer_16bit = NULL;
    RTC_LOG(LS_INFO) << "[Process] release OutBuffer & OutBuffer_16bit";
  }
	RTC_LOG(LS_INFO) << "[Process] release SR-LUT";
}

__m256i* SRLutCPU::SetLut() {
	static __m256i LUT_fin[83521]; //83521=17^4
	memcpy(LUT_fin, LUThexData_enhanced_row1324, 83521 * sizeof(__m256i));
  RTC_LOG(LS_INFO) << "[Process] set LUT";
	return LUT_fin;
}

void SRLutCPU::initOutBuffer(){
  // 360 * 640 *4 * 3/2 = 1382400
  // 360 * 640 *4 + 64 = 921664
  if (mOutBufferIsNewed){
    delete[] outBuffer;
    outBuffer = NULL;
    delete[] outBuffer_16bit;
    outBuffer_16bit = NULL;
  }
  outBuffer = new int8_t[921664];
  outBuffer_16bit = new int16_t[921664];
  mOutBufferIsNewed = true;
  RTC_LOG(LS_INFO) << "[Process] New OutBuffer & OutBuffer_16bit";
  return;
}

bool SRLutCPU::CheckCondition(VideoFrame& input_frame) {
  int src_width = input_frame.width();
  int src_height = input_frame.height();
  if ((src_width == 640 && src_height == 360) || (src_width == 360 && src_height == 640)) {  // only support 360p
    return true;
  }
  //RTC_LOG(LS_INFO)<<"[Process] wrong resolution!";
  return false;
}

void SRLutCPU::initParams() {
	if (!mIsInit) {
    LUT_ = SetLut();
    initOutBuffer();
    mIsInit = true;
  }
  RTC_LOG(LS_INFO) << "[Process] Init LUT";
}

rtc::scoped_refptr<VideoFrameBuffer> SRLutCPU::ProcessFilter(VideoFrame& input_frame, I420BufferPool& buffer_pool) {
	rtc::scoped_refptr<VideoFrameBuffer> input_buffer_ = input_frame.video_frame_buffer();
	rtc::scoped_refptr<I420BufferInterface> i420Buffer = input_buffer_->ToI420();
  inlinesize = i420Buffer->StrideU(); 
	outlinesize = i420Buffer->width();

  int src_width_aligned = i420Buffer->StrideY(); //384
  int src_width = input_frame.width(); //360
  int src_height = input_frame.height(); //640
  int dst_frameSizeY = src_width * src_height * 4;
  int dst_width = 2 * src_width;
  int dst_height = 2 * src_height;
    
	if (!mIsInit) {
		initParams();
		mIsInit = true;
	}

	if ((src_width != 640 || src_height != 360) && (src_width != 360 || src_height != 640)) {  // only support 360p 	
	 //RTC_LOG(LS_INFO) << "[Process] Only support 360p, break\n";
   return input_buffer_;
  }

  //RTC_LOG(LS_INFO) << "[Process] begin SR-LUT"<<src_width_aligned<<", src_width="<<src_width;
  //auto start = chrono::high_resolution_clock::now();
	int L = 17, L2 = 289, L3 = 4913;
  __m256i cstq = _mm256_set1_epi16(16);
  __m256i cst0 = _mm256_setzero_si256();
  __m256i cst255 = _mm256_set1_epi16(255);
  __m256i cstshuffleindex_corner = _mm256_setr_epi8(6, 4, 2, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 6, 4, 2, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
  __m256i cstshuffleindex_corner2 = _mm256_setr_epi8(10, 8, 2, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 10, 8, 2, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
  __m256i cstwriteindex0123 = _mm256_setr_epi8(0, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);

	memset(outBuffer, 0, dst_frameSizeY+64);
  memset(outBuffer_16bit, 0, 2*(dst_frameSizeY+64));

	inBuffer = (uint8_t*)i420Buffer->DataY();
	inbuf[0] = (uint8_t*)i420Buffer->DataU();
	inbuf[1] = (uint8_t*)i420Buffer->DataV();

	rtc::scoped_refptr<I420Buffer> dst = buffer_pool.CreateBuffer(dst_width, dst_height);
	outbuf[0] = dst->MutableDataY();
  outbuf[1] = dst->MutableDataU();
  outbuf[2] = dst->MutableDataV();
  //auto start = chrono::high_resolution_clock::now();

  int img1[640];
  __m256i fi_256[640];

  for (int kk = 0; kk < src_width; ++kk) {
    img1[kk] = inBuffer[kk] >>4;
    fi_256[kk] = _mm256_set1_epi16(inBuffer[kk] & 0x0f);
  }

  // main loop
  for (int i = 0; i < src_height - 2; i += 2) {
    int in_index_row1 = i * src_width_aligned;
    int in_index_row2 = in_index_row1 + src_width_aligned;
    int in_index_row3 = in_index_row2 + src_width_aligned;

    int img_b1 = img1[0];
    __m256i fb_256 = fi_256[0];

    int img_d1 = inBuffer[in_index_row2] >> 4;
    __m256i fd_256 = _mm256_set1_epi16(inBuffer[in_index_row2] & 0x0f);

    int img_f1 = inBuffer[in_index_row3] >> 4;
    __m256i ff_256 = _mm256_set1_epi16(inBuffer[in_index_row3] & 0x0f);

    img1[0] = img_f1;
    fi_256[0] = ff_256;

    int tmpj = 0;

    for (int j = 0; j < src_width - 1; ++j) {
      int img_a1 = img_b1;
      __m256i fa_256 = fb_256;

      int img_c1 = img_d1;
      __m256i fc_256 = fd_256;

      int img_e1 = img_f1;
      __m256i fe_256 = ff_256;

      img_b1 = img1[j + 1];
      fb_256 = fi_256[j + 1];

      img_d1 = (inBuffer[in_index_row2 + j + 1]) >> 4;
      fd_256 = _mm256_set1_epi16(inBuffer[in_index_row2 + j + 1] & 0x0f);

      img_f1 = (inBuffer[in_index_row3 + j + 1]) >> 4;
      ff_256 = _mm256_set1_epi16(inBuffer[in_index_row3 + j + 1] & 0x0f);

      img1[j+1] = img_f1;
      fi_256[j+1] = ff_256;

      __m256i w1_ = _mm256_sub_epi16(cstq, fa_256);
      int ip_tmp = img_c1 * L + img_d1;
      int ip0000_1 = img_a1 * L3 + img_b1 * L2 + ip_tmp;
      __m256i o0_1 = _mm256_mullo_epi16(w1_, *(LUT_ + ip0000_1));

      __m256i w2_ = _mm256_sub_epi16(fa_256, fb_256);
      int ip1000_1 = ip0000_1 + L3;
      __m256i o1_1 = _mm256_mullo_epi16(w2_, *(LUT_ + ip1000_1));

      __m256i w3_ = _mm256_sub_epi16(fb_256, fc_256);
      int ip1100_1 = ip1000_1 + L2;
      __m256i o2_1 = _mm256_mullo_epi16(w3_, *(LUT_ + ip1100_1));

      __m256i w4_ = _mm256_sub_epi16(fc_256, fd_256);
      int ip1110_1 = ip1100_1 + L;
      __m256i o3_1 = _mm256_mullo_epi16(w4_, *(LUT_ + ip1110_1));

      int ip1111_1 = ip1110_1 + 1;
      __m256i o4_1 = _mm256_mullo_epi16(fd_256, *(LUT_ + ip1111_1));

      __m256i out_256_1 = _mm256_add_epi16(_mm256_add_epi16(o0_1, o1_1), _mm256_add_epi16(o2_1, o3_1));
      out_256_1 = _mm256_add_epi16(out_256_1, o4_1);
      out_256_1 = _mm256_srai_epi16(out_256_1, 4);

      //out_256_1 = _mm256_shuffle_epi8(out_256_1, cstshuffleindex);

      int out_index_row1 = 4 * i * src_width;
      int out_index_row2 = out_index_row1 + dst_width;
      int out_index_row3 = out_index_row2 + dst_width;
      int out_index_row4 = out_index_row3 + dst_width;

      //20211124
      __m256i out_12 = _mm256_loadu2_m128i((__m128i*)(outBuffer_16bit + out_index_row2 + tmpj), (__m128i*)(outBuffer_16bit + out_index_row1 + tmpj));
      out_12 = _mm256_add_epi16(out_12, _mm256_blend_epi32(out_256_1, cst0, 0b11001100));
      _mm256_storeu2_m128i((__m128i*)(outBuffer_16bit + out_index_row2 + tmpj), (__m128i*)(outBuffer_16bit + out_index_row1 + tmpj), out_12);
      out_12 = _mm256_shuffle_epi8(_mm256_max_epi16(_mm256_min_epi16(out_12, cst255), cst0), cstwriteindex0123);
      __m128i *out_0123_ptr = (__m128i*)&out_12;
      _mm_storeu_si16((outBuffer + out_index_row1 + tmpj), *(out_0123_ptr));
      _mm_storeu_si16((outBuffer + out_index_row2 + tmpj), *(out_0123_ptr+1));

      ///////////////////////////////////////

      __m256i w5_ = _mm256_sub_epi16(cstq, fc_256);
      int ip0000_2 = ip_tmp * L2 + img_e1 * L + img_f1;
      __m256i o0_2 = _mm256_mullo_epi16(w5_, *(LUT_ + ip0000_2));

      int ip1000_2 = ip0000_2 + L3;
      __m256i o1_2 = _mm256_mullo_epi16(w4_, *(LUT_ + ip1000_2));

      __m256i w6_ = _mm256_sub_epi16(fd_256, fe_256);
      int ip1100_2 = ip1000_2 + L2;
      __m256i o2_2 = _mm256_mullo_epi16(w6_, *(LUT_ + ip1100_2));

      __m256i w7_ = _mm256_sub_epi16(fe_256, ff_256);
      int ip1110_2 = ip1100_2 + L;
      __m256i o3_2 = _mm256_mullo_epi16(w7_, *(LUT_ + ip1110_2));

      int ip1111_2 = ip1110_2 + 1;
      __m256i o4_2 = _mm256_mullo_epi16(ff_256, *(LUT_ + ip1111_2));

      __m256i out_256_2 = _mm256_add_epi16(_mm256_add_epi16(o0_2, o1_2), _mm256_add_epi16(o2_2, o3_2));
      out_256_2 = _mm256_add_epi16(out_256_2, o4_2);
      out_256_2 = _mm256_srai_epi16(out_256_2, 4);

      int out_index_row5 = out_index_row4 + dst_width;
      int out_index_row6 = out_index_row5 + dst_width;

      __m256i out_34 = _mm256_loadu2_m128i((__m128i*)(outBuffer_16bit + out_index_row4 + tmpj), (__m128i*)(outBuffer_16bit + out_index_row3 + tmpj));
      out_34 = _mm256_add_epi16(out_34, _mm256_bsrli_epi128(out_256_1, 8));
      out_34 = _mm256_add_epi16(out_34, _mm256_blend_epi32(out_256_2, cst0, 0b11001100));
      _mm256_storeu2_m128i((__m128i*)(outBuffer_16bit + out_index_row4 + tmpj), (__m128i*)(outBuffer_16bit + out_index_row3 + tmpj), out_34);
      out_34 = _mm256_shuffle_epi8(_mm256_max_epi16(_mm256_min_epi16(out_34, cst255), cst0), cstwriteindex0123);
      __m128i *out_4567_ptr = (__m128i*)&out_34;
      _mm_storeu_si16((outBuffer + out_index_row3 + tmpj), *(out_4567_ptr));
      _mm_storeu_si16((outBuffer + out_index_row4 + tmpj), *(out_4567_ptr+1));

      __m256i out_56 = _mm256_loadu2_m128i((__m128i*)(outBuffer_16bit + out_index_row6 + tmpj -4), (__m128i*)(outBuffer_16bit + out_index_row5 + tmpj -4));
      out_56 = _mm256_add_epi16(out_56, _mm256_blend_epi32(out_256_2, cst0, 0b00110011));
      _mm256_storeu2_m128i((__m128i*)(outBuffer_16bit + out_index_row6 + tmpj -4), (__m128i*)(outBuffer_16bit + out_index_row5 + tmpj -4), out_56);

      tmpj += 2;
      }
    }

  //auto finish = chrono::high_resolution_clock::now();
  ///////corner case
  if (!(src_height & 1)) {  // only nums % 2==0 into this loop
    int out_index_row1 = (2 * src_height - 4) * dst_width;
    int out_index_row2 = out_index_row1 + dst_width;
    int out_index_row3 = out_index_row2 + dst_width;
    int out_index_row4 = out_index_row3 + dst_width;

    int in_index_row1 = (src_height - 2) * src_width_aligned;
    int in_index_row2 = in_index_row1 + src_width_aligned;

    int img_b1 = img1[0];
    __m256i fb_256 = fi_256[0];

    int img_d1 = inBuffer[in_index_row2] >> 4;
    __m256i fd_256 = _mm256_set1_epi16(inBuffer[in_index_row2] & 0x0f);

    img1[0] = img_d1;
    fi_256[0] = fd_256;

    int tmpj = 0;                      
    for (int j = 0; j < src_width - 1; ++j) {  
      int img_a1 = img_b1;
      __m256i fa_256 = fb_256;

      int img_c1 = img_d1;
      __m256i fc_256 = fd_256;

      img_b1 = img1[j+1];
      fb_256 = fi_256[j+1];

      img_d1 = (inBuffer[in_index_row2 + j + 1] >> 4);
      fd_256 = _mm256_set1_epi16(inBuffer[in_index_row2 + j + 1] & 0x0f);

      img1[j + 1] = img_d1;
      fi_256[j + 1] = fd_256;

      int ip0000 = img_a1 * L3 + img_b1 * L2 + img_c1 * L + img_d1;
      int ip1000 = ip0000 + L3;
      int ip1100 = ip1000 + L2;
      int ip1110 = ip1100 + L;
      int ip1111 = ip1110 + 1;

      __m256i w1_ = _mm256_sub_epi16(cstq, fa_256);
      __m256i w2_ = _mm256_sub_epi16(fa_256, fb_256);
      __m256i w3_ = _mm256_sub_epi16(fb_256, fc_256);
      __m256i w4_ = _mm256_sub_epi16(fc_256, fd_256);

      __m256i o0, o1, o2, o3, o4, out_256;

      o0 = _mm256_mullo_epi16(w1_, LUT_[ip0000]);
      o1 = _mm256_mullo_epi16(w2_, LUT_[ip1000]);
      o2 = _mm256_mullo_epi16(w3_, LUT_[ip1100]);
      o3 = _mm256_mullo_epi16(w4_, LUT_[ip1110]);
      o4 = _mm256_mullo_epi16(fd_256, LUT_[ip1111]);

      out_256 = _mm256_add_epi16(_mm256_add_epi16(o0, o1), _mm256_add_epi16(o2, o3));
      out_256 = _mm256_add_epi16(out_256, o4);
      out_256 = _mm256_srai_epi16(out_256, 4);

      //20211125, corner case
      __m256i out_12 = _mm256_loadu2_m128i((__m128i*)(outBuffer_16bit + out_index_row2 + tmpj), (__m128i*)(outBuffer_16bit + out_index_row1 + tmpj));
      out_12 = _mm256_add_epi16(out_12, _mm256_blend_epi32(out_256, cst0, 0b11001100));
      _mm256_storeu2_m128i((__m128i*)(outBuffer_16bit + out_index_row2 + tmpj), (__m128i*)(outBuffer_16bit + out_index_row1 + tmpj), out_12);

      out_12 = _mm256_shuffle_epi8(out_12, cstwriteindex0123);
      __m128i *out_0123_ptr = (__m128i*)&out_12;
      _mm_storeu_si16((outBuffer + out_index_row1 + tmpj), *(out_0123_ptr));
      _mm_storeu_si16((outBuffer + out_index_row2 + tmpj), *(out_0123_ptr+1));

      __m256i out_34 = _mm256_loadu2_m128i((__m128i*)(outBuffer_16bit + out_index_row4 + tmpj -4), (__m128i*)(outBuffer_16bit + out_index_row3 + tmpj -4));
      out_34 = _mm256_add_epi16(out_34, _mm256_blend_epi32(out_256, cst0, 0b00110011));
      _mm256_storeu2_m128i((__m128i*)(outBuffer_16bit + out_index_row4 + tmpj -4), (__m128i*)(outBuffer_16bit + out_index_row3 + tmpj -4), out_34);

      tmpj += 2;
    }
  }

  // case1 cbgf as abcd, correct
  int img_c1_ = inBuffer[0] >> 4;  
  __m256i fc_ = _mm256_set1_epi16(inBuffer[0] & 0x0f);

  int img_g1_ = inBuffer[src_width] >> 4;  
  __m256i fg_ = _mm256_set1_epi16(inBuffer[src_width] & 0x0f);

  int tmpj = 0;                      
  for (int j = 0; j < src_width - 1; ++j) {  

    int img_b1_ = img_c1_;
    __m256i fb_ = fc_;

    int img_f1_ = img_g1_;
    __m256i ff_ = fg_;

    img_c1_ = inBuffer[j + 1] >> 4;
    fc_ = _mm256_set1_epi16(inBuffer[j + 1] & 0x0f);
    img_g1_ = inBuffer[src_width + j + 1] >> 4;
    fg_ = _mm256_set1_epi16(inBuffer[src_width + j + 1] & 0x0f);

    int ip0000 = img_c1_ * L3 + img_b1_ * L2 + img_g1_ * L + img_f1_;
    int ip1000 = ip0000 + L3;
    int ip1100 = ip1000 + L2;
    int ip1110 = ip1100 + L;
    int ip1111 = ip1110 + 1;

    __m256i w1_ = _mm256_sub_epi16(cstq, fc_);
    __m256i w2_ = _mm256_sub_epi16(fc_, fb_);
    __m256i w3_ = _mm256_sub_epi16(fb_, fg_);
    __m256i w4_ = _mm256_sub_epi16(fg_, ff_);

    __m256i o0_ = _mm256_mullo_epi16(w1_, LUT_[ip0000]);
    __m256i o1_ = _mm256_mullo_epi16(w2_, LUT_[ip1000]);
    __m256i o2_ = _mm256_mullo_epi16(w3_, LUT_[ip1100]);
    __m256i o3_ = _mm256_mullo_epi16(w4_, LUT_[ip1110]);
    __m256i o4_ = _mm256_mullo_epi16(ff_, LUT_[ip1111]);

    __m256i out_256_ = _mm256_add_epi16(_mm256_add_epi16(o0_, o1_), _mm256_add_epi16(o2_, o3_));
    out_256_ = _mm256_add_epi16(out_256_, o4_);
    out_256_ = _mm256_srai_epi16(out_256_, 4);

    out_256_ = _mm256_shuffle_epi8(out_256_, cstshuffleindex_corner);

    __m256i out_p12_ = _mm256_loadu2_m128i((__m128i*)(outBuffer + tmpj), (__m128i*)(outBuffer + tmpj + dst_width));
    out_p12_ = _mm256_add_epi8(out_p12_, _mm256_blend_epi32(out_256_, cst0, 0b11101110));
    _mm256_storeu2_m128i((__m128i*)(outBuffer + tmpj), (__m128i*)(outBuffer + tmpj + dst_width), out_p12_);

    tmpj += 2;
  }

  // case2 nojk as abcd, correct
  int tmp_r1 = (src_height - 1) * src_width_aligned;
  int tmp_r2 = (src_height - 2) * src_width_aligned;

  int img_o1_ = inBuffer[tmp_r1] >> 4;  
  __m256i fo_ = _mm256_set1_epi16(inBuffer[tmp_r1] & 0x0f);

  int img_k1_ = inBuffer[tmp_r2] >> 4; 
  __m256i fk_ = _mm256_set1_epi16(inBuffer[tmp_r2] & 0x0f);

  tmpj = 0;
  for (int j = 0; j < src_width - 1; ++j) {  // i=0 ori j=1

    int img_n1_ = img_o1_;
    __m256i fn_ = fo_;

    int img_j1_ = img_k1_;
    __m256i fj_ = fk_;

    img_o1_ = inBuffer[tmp_r1 + j + 1] >> 4;
    fo_ = _mm256_set1_epi16(inBuffer[tmp_r1 + j + 1] & 0x0f);
    img_k1_ = inBuffer[tmp_r2 + j + 1] >> 4;
    fk_ = _mm256_set1_epi16(inBuffer[tmp_r2 + j + 1] & 0x0f);

    int ip0000 = img_n1_ * L3 + img_o1_ * L2 + img_j1_ * L + img_k1_;
    int ip1000 = ip0000 + L3;
    int ip1100 = ip1000 + L2;
    int ip1110 = ip1100 + L;
    int ip1111 = ip1110 + 1;

    __m256i w1_ = _mm256_sub_epi16(cstq, fn_);
    __m256i w2_ = _mm256_sub_epi16(fn_, fo_);
    __m256i w3_ = _mm256_sub_epi16(fo_, fj_);
    __m256i w4_ = _mm256_sub_epi16(fj_, fk_);

    __m256i o0_ = _mm256_mullo_epi16(w1_, LUT_[ip0000]);
    __m256i o1_ = _mm256_mullo_epi16(w2_, LUT_[ip1000]);
    __m256i o2_ = _mm256_mullo_epi16(w3_, LUT_[ip1100]);
    __m256i o3_ = _mm256_mullo_epi16(w4_, LUT_[ip1110]);
    __m256i o4_ = _mm256_mullo_epi16(fk_, LUT_[ip1111]);

    __m256i out_256_ = _mm256_add_epi16(_mm256_add_epi16(o0_, o1_), _mm256_add_epi16(o2_, o3_));
    out_256_ = _mm256_add_epi16(out_256_, o4_);
    out_256_ = _mm256_srai_epi16(out_256_, 4);

    int tmp_r_out = src_height -1;
    __m256i out_p34_ = _mm256_loadu2_m128i((__m128i*)(outBuffer_16bit + 2 * tmp_r_out * dst_width + dst_width + tmpj), (__m128i*)(outBuffer_16bit + 2 * tmp_r_out * dst_width + tmpj));
    out_p34_ = _mm256_add_epi16(out_p34_, _mm256_blend_epi32(out_256_, cst0, 0b11001100));
    _mm256_storeu2_m128i((__m128i*)(outBuffer_16bit + 2 * tmp_r_out * dst_width + dst_width + tmpj), (__m128i*)(outBuffer_16bit + 2 * tmp_r_out * dst_width + tmpj), out_p34_);
    out_p34_ = _mm256_shuffle_epi8(out_p34_, cstwriteindex0123);
    __m128i* out_3456_ptr = (__m128i*)&out_p34_;
    _mm_storeu_si16((outBuffer + 2 * tmp_r_out * dst_width + tmpj), *(out_3456_ptr));
    _mm_storeu_si16((outBuffer + 2 * tmp_r_out * dst_width + dst_width + tmpj), *(out_3456_ptr+1));

    tmpj += 2;
  }

  // case3 ijef as abcd
  int img_i1_ = inBuffer[0] >> 4;  
  __m256i fi_ = _mm256_set1_epi16(inBuffer[0] & 0x0f);

  int img_j1_ = inBuffer[1] >> 4;  
  __m256i fj_ = _mm256_set1_epi16(inBuffer[1] & 0x0f);

  int tmpi = 0;
  for (int i = 0; i < src_height - 1; ++i) {  
    int img_e1_ = img_i1_;
    __m256i fe_ = fi_;
    int img_f1_ = img_j1_;
    __m256i ff_ = fj_;

    img_i1_ = inBuffer[(i + 1) * src_width_aligned] >> 4;
    fi_ = _mm256_set1_epi16(inBuffer[(i + 1) * src_width_aligned] & 0x0f);
    img_j1_ = inBuffer[(i + 1) * src_width_aligned + 1] >> 4;
    fj_ = _mm256_set1_epi16(inBuffer[(i + 1) * src_width_aligned + 1] & 0x0f);

    int ip0000 = img_i1_ * L3 + img_j1_ * L2 + img_e1_ * L + img_f1_;
    int ip1000 = ip0000 + L3;
    int ip1100 = ip1000 + L2;
    int ip1110 = ip1100 + L;
    int ip1111 = ip1110 + 1;

    __m256i w1_ = _mm256_sub_epi16(cstq, fi_);
    __m256i w2_ = _mm256_sub_epi16(fi_, fj_);
    __m256i w3_ = _mm256_sub_epi16(fj_, fe_);
    __m256i w4_ = _mm256_sub_epi16(fe_, ff_);

    __m256i o0_ = _mm256_mullo_epi16(w1_, LUT_[ip0000]);
    __m256i o1_ = _mm256_mullo_epi16(w2_, LUT_[ip1000]);
    __m256i o2_ = _mm256_mullo_epi16(w3_, LUT_[ip1100]);
    __m256i o3_ = _mm256_mullo_epi16(w4_, LUT_[ip1110]);
    __m256i o4_ = _mm256_mullo_epi16(ff_, LUT_[ip1111]);

    __m256i out_256_ = _mm256_add_epi16(_mm256_add_epi16(o0_, o1_), _mm256_add_epi16(o2_, o3_));
    out_256_ = _mm256_add_epi16(out_256_, o4_);
    out_256_ = _mm256_srai_epi16(out_256_, 4);

    out_256_ = _mm256_shuffle_epi8(out_256_, cstshuffleindex_corner2);

    __m256i out_p12 = _mm256_loadu2_m128i((__m128i*)(outBuffer + tmpi * dst_width), (__m128i*)(outBuffer + (tmpi + 1) * dst_width));
    out_p12 = _mm256_add_epi8(out_p12, _mm256_blend_epi16(out_256_, cst0, 0b11101110));
    _mm256_storeu2_m128i((__m128i*)(outBuffer + tmpi * dst_width), (__m128i*)(outBuffer + (tmpi + 1) * dst_width), out_p12);

    __m256i out_p34 = _mm256_loadu2_m128i((__m128i*)(outBuffer + (tmpi + 2) * dst_width-2), (__m128i*)(outBuffer + (tmpi + 3) * dst_width - 2));
    out_p34 = _mm256_add_epi8(out_p34, _mm256_blend_epi16(out_256_, cst0, 0b11011101));
    _mm256_storeu2_m128i((__m128i*)(outBuffer + (tmpi + 2) * dst_width-2), (__m128i*)(outBuffer + (tmpi + 3) * dst_width - 2), out_p34);

    tmpi += 2;
  }

  // case4 hglk as abcd //j=c-2
  int img_l1_ = inBuffer[src_width - 1] >> 4;  
  __m256i fl_ = _mm256_set1_epi16(inBuffer[src_width - 1] & 0x0f);

  img_k1_ = inBuffer[src_width - 2] >> 4;  
  fk_ = _mm256_set1_epi16(inBuffer[src_width - 2] & 0x0f);

  tmpi = 0;
  for (int i = 0; i < src_height - 1; ++i) {  

    int img_h1_ = img_l1_;
    __m256i fh_ = fl_;

    int img_g1_ = img_k1_;
    __m256i fg_ = fk_;

    int tmp_r = i * src_width_aligned + src_width;
    img_l1_ = inBuffer[tmp_r + src_width_aligned - 1] >> 4;
    fl_ = _mm256_set1_epi16(inBuffer[tmp_r + src_width_aligned - 1] & 0x0f);

    img_k1_ = inBuffer[tmp_r + src_width_aligned - 2] >> 4;
    fk_ = _mm256_set1_epi16(inBuffer[tmp_r + src_width_aligned - 2] & 0x0f);

    int ip0000 = img_h1_ * L3 + img_g1_ * L2 + img_l1_ * L + img_k1_;
    int ip1000 = ip0000 + L3;
    int ip1100 = ip1000 + L2;
    int ip1110 = ip1100 + L;
    int ip1111 = ip1110 + 1;

    __m256i w1_ = _mm256_sub_epi16(cstq, fh_);
    __m256i w2_ = _mm256_sub_epi16(fh_, fg_);
    __m256i w3_ = _mm256_sub_epi16(fg_, fl_);
    __m256i w4_ = _mm256_sub_epi16(fl_, fk_);

    __m256i o0_ = _mm256_mullo_epi16(w1_, LUT_[ip0000]);
    __m256i o1_ = _mm256_mullo_epi16(w2_, LUT_[ip1000]);
    __m256i o2_ = _mm256_mullo_epi16(w3_, LUT_[ip1100]);
    __m256i o3_ = _mm256_mullo_epi16(w4_, LUT_[ip1110]);
    __m256i o4_ = _mm256_mullo_epi16(fk_, LUT_[ip1111]);

    __m256i out_256_ = _mm256_add_epi16(_mm256_add_epi16(o0_, o1_), _mm256_add_epi16(o2_, o3_));
    out_256_ = _mm256_add_epi16(out_256_, o4_);
    out_256_ = _mm256_srai_epi16(out_256_, 4);

    int biasj = dst_width -2;

    __m256i out_p12_ = _mm256_loadu2_m128i((__m128i*)(outBuffer_16bit + (tmpi + 1) * dst_width + biasj), (__m128i*)(outBuffer_16bit + tmpi * dst_width + biasj));
    out_p12_ = _mm256_add_epi16(out_p12_, out_256_);
    _mm256_storeu2_m128i((__m128i*)(outBuffer_16bit + (tmpi + 1) * dst_width + biasj), (__m128i*)(outBuffer_16bit + tmpi * dst_width + biasj), out_p12_);
    out_p12_ = _mm256_shuffle_epi8(out_p12_, cstwriteindex0123);
    __m128i* out_p1234_ptr = (__m128i*)&out_p12_;
    _mm_storeu_si16((outBuffer + tmpi * dst_width + biasj), *(out_p1234_ptr));
    _mm_storeu_si16((outBuffer + (tmpi + 1) * dst_width + biasj), *(out_p1234_ptr+1));

    __m256i out_p34_ = _mm256_loadu2_m128i((__m128i*)(outBuffer_16bit + (tmpi + 3) * dst_width + biasj - 4), (__m128i*)(outBuffer_16bit + (tmpi + 2) * dst_width + biasj - 4));
    out_p34_ = _mm256_add_epi16(out_p34_, out_256_);
    _mm256_storeu2_m128i((__m128i*)(outBuffer_16bit + (tmpi + 3) * dst_width + biasj - 4), (__m128i*)(outBuffer_16bit + (tmpi + 2) * dst_width + biasj - 4), out_p34_);

    tmpi += 2;
  }

  //auto finish = chrono::high_resolution_clock::now();
  memset(outBuffer, inBuffer[0],2);
  memset(outBuffer + dst_width, inBuffer[0], 2);
  memset(outBuffer + dst_width -2, inBuffer[src_width-1], 2);
  memset(outBuffer + dst_width + dst_width -2, inBuffer[src_width-1], 2);
  memset(outBuffer + (dst_height -2)*dst_width, inBuffer[src_width*(src_height-1)], 2);
  memset(outBuffer + (dst_height -1)*dst_width, inBuffer[src_width*(src_height-1)], 2);
  memset(outBuffer + (dst_height -1)*dst_width -2, inBuffer[src_width*src_height-1], 2);
  memset(outBuffer + dst_height*dst_width -2, inBuffer[src_width*src_height-1], 2);

	memcpy(outbuf[0], outBuffer, dst_frameSizeY);

	ScalePlane(inbuf[0], inlinesize, i420Buffer->width() / 2, i420Buffer->height() / 2, outbuf[1], outlinesize, i420Buffer->width(), i420Buffer->height(), libyuv::kFilterBilinear);
	ScalePlane(inbuf[1], inlinesize, i420Buffer->width() / 2, i420Buffer->height() / 2, outbuf[2], outlinesize, i420Buffer->width(), i420Buffer->height(), libyuv::kFilterBilinear);
	return dst;
}

//VideoProcessResult SRLUTCPU::ProcessFilter( std::unique_ptr<VideoProcessData>& process_param) {
//  if (process_param && process_param->GetPostProcessInputParam().input_frame &&
//      process_param->GetPostProcessInputParam().buffer_pool) {
//    process_param->PostProcessResult().dst_video_frame_buf_ =
//        ProcessFilter(*(process_param->GetPostProcessInputParam().input_frame),
//                      *(process_param->GetPostProcessInputParam().buffer_pool));
//    return VIDEO_PROCESS_RES_SUC;
//  }
//  return VIDEO_PROCESS_RES_FAILED;
//}

rtc::scoped_refptr<VideoFrameBuffer> SRLutCPU::ProcessFilter(std::unique_ptr<VideoProcessData>& process_param) {
    if (process_param &&
        process_param->GetPostProcessInputParam().input_frame &&
        process_param->GetPostProcessInputParam().buffer_pool) {
        return ProcessFilter(*(process_param->GetPostProcessInputParam().input_frame),
            *(process_param->GetPostProcessInputParam().buffer_pool));
    }
    return nullptr;
}

}
